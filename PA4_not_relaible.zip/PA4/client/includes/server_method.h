
#include "common.h"


commands_t whichcmd(int argc, char *argv[]);
void print_menu();